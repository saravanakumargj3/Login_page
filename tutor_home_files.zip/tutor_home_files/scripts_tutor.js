// Function to toggle the sidebar
function toggleSidebar() {
    var sidebar = document.getElementById('sidebar');
    if (sidebar.style.display === 'none') {
        sidebar.style.display = 'block';
        document.addEventListener('click', closeSidebarOutsideClick);
    } else {
        sidebar.style.display = 'none';
        document.removeEventListener('click', closeSidebarOutsideClick);
    }
}

// Function to close the sidebar when clicking outside
function closeSidebarOutsideClick(event) {
    var sidebar = document.getElementById('sidebar');
    var menuBtn = document.querySelector('.menu-btn');
    if (!sidebar.contains(event.target) && event.target !== menuBtn) {
        sidebar.style.display = 'none';
        document.removeEventListener('click', closeSidebarOutsideClick);
    }
}

// Function to toggle showing more teams
function toggleMore() {
    var moreButton = document.getElementById('moreButton');
    var hiddenTeams = document.querySelectorAll('.hidden');
    hiddenTeams.forEach(team => {
        team.classList.toggle('hidden');
    });
    moreButton.style.display = 'none'; // Hide the more button after clicking
}

// Fetch team names from MongoDB
async function fetchTeamNames() {
    try {
        const response = await fetch('http://localhost:3000/teams'); // Assuming your server endpoint to fetch team names
        const data = await response.json();
        return data.teams; // Assuming the JSON response contains an array of team names under the key 'teams'
    } catch (error) {
        console.error('Error fetching team names:', error);
        return [];
    }
}

// Function to dynamically populate leaderboard with team names
async function populateLeaderboard() {
    const leaderboardList = document.getElementById('leaderboardList');
    const teams = await fetchTeamNames();
    if (teams.length > 0) {
        leaderboardList.innerHTML = ''; // Clear previous content
        teams.forEach(team => {
            const li = document.createElement('li');
            li.textContent = team;
            leaderboardList.appendChild(li);
        });
    } else {
        leaderboardList.innerHTML = '<li>No teams found</li>'; // Display message if no teams are retrieved
    }
}

// Function to fetch lab sessions from MongoDB
async function fetchLabSessions() {
    try {
        const response = await fetch('http://localhost:3000/lab-sessions'); // Assuming your server endpoint to fetch lab sessions
        const data = await response.json();
        return data.labSessions; // Assuming the JSON response contains an array of lab sessions
    } catch (error) {
        console.error('Error fetching lab sessions:', error);
        return [];
    }
}

// Function to dynamically populate lab sessions
async function populateLabSessions() {
    const labSessionsTable = document.getElementById('labSessionsTable');
    const labSessions = await fetchLabSessions();
    if (labSessions.length > 0) {
        labSessions.forEach(session => {
            const row = labSessionsTable.insertRow();
            row.insertCell(0).textContent = session.date;
            row.insertCell(1).textContent = session.time;
            row.insertCell(2).textContent = session.topic;
        });
    } else {
        const row = labSessionsTable.insertRow();
        row.insertCell(0).textContent = 'No sessions found';
    }
}

// Call the function to populate leaderboard when the page loads
populateLeaderboard();

// Call the function to populate lab sessions when the page loads
populateLabSessions();
